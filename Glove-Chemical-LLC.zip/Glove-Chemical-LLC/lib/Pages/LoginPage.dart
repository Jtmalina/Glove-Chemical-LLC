import 'package:flutter/material.dart';
import 'package:test_app/Pages/NotePage.dart';
import 'package:firebase_auth/firebase_auth.dart';

class LoginPage extends StatefulWidget{
  @override
  _LoginPageState createState() => new _LoginPageState();
}

class _LoginPageState extends State<LoginPage>{
  String _email, _password;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        title: Text('Sign In'),
        backgroundColor: Colors.red[800],
      ),
      body: Form(
        child: Column(
          children: <Widget>[
            TextFormField(
              validator: (input){
                if(input.isEmpty){
                  return 'Please type an email';
                }
              },
              onSaved: (input) => _email = input,
              decoration: InputDecoration(
                labelText: 'Email'
              )
            ),
            TextFormField(
              validator: (input){
                if(input.length < 6){
                  return 'Your password must be at least 6 characters';
                }
                },
              onSaved: (input) => _password = input,
              decoration: InputDecoration(
                  labelText: 'Password'
              ),
              obscureText: true,
            ),
            RaisedButton(
              onPressed: signI,
              child: Text('Sign In'),
            )
          ],
        )
      )
    );
  }

  Future<void> signIn() async{
    //validate fields
    final formState = _formKey.currentState;
    if(formState.validate()){
      //if true, login to firebase
      formState.save(); // this makes sure the variabels et saved from textbox
      try{
        //the login worked so go to new page
        FirebaseUser user = await FirebaseAuth.instance.signInWithEmailAndPassword(email: _email, password: _password);
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => NotePage()),
        );
      }
      catch(e){
        //login didn't work
        print(e.message);
      }
    }
  }
}


/*
class LoginPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Glove Chemical, LLC"),
        backgroundColor: Colors.red[800],
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            children: <Widget>[
              Container(
                color: Colors.grey,
                width: 450.0,
                padding: EdgeInsets.all(10),
                child: Text(
                  'Phone Number:',
                  style: TextStyle(
                    fontSize: 25,
                    //background: Paint()..color = Colors.grey
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              Container(
                padding: EdgeInsets.all(10),
                child: TextField(
                  enableInteractiveSelection: true,
                  autocorrect: true,
                  autofocus: true,
                  enabled: true,
                  textAlign: TextAlign.center,
                  maxLength: 13,
                  decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      hintText: "(xxx)xxx-xxxx"
                  ),
                ),
              ),
              Container(
                padding: EdgeInsets.all(10),
                color: Colors.grey,
                width: 450.0,
                child: Text(
                  'PO/DEPARTMENT:',
                  style: TextStyle(fontSize: 25),
                  textAlign: TextAlign.center,
                ),
              ),
              Container(
                padding: EdgeInsets.all(10),
                child:TextField(
                  enableInteractiveSelection: true,
                  autocorrect: true,
                  autofocus: true,
                  enabled: true,
                  textAlign: TextAlign.center,
                  decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      hintText: "xxxx"
                  ),
                ),
              ),
              Container(
                padding: EdgeInsets.all(10),
                child:Text(
                  'NEW USERS:',
                  style: TextStyle(
                      fontSize: 25,
                      fontWeight: FontWeight.bold,
                      decoration: TextDecoration.underline
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              Container(
                padding: EdgeInsets.all(10),
                color: Colors.grey,
                width: 450.0,
                child: Text(
                  'Facility Name:',
                  style: TextStyle(fontSize: 25),
                  textAlign: TextAlign.center,
                ),
              ),
              Container(
                padding: EdgeInsets.all(10),
                child: TextField(
                  enableInteractiveSelection: true,
                  autocorrect: true,
                  enabled: true,
                  autofocus: true,
                  textAlign: TextAlign.center,
                  decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      hintText: "xxxx"
                  ),
                ),
              ),
              Container(
                padding: EdgeInsets.all(10),
                color: Colors.grey,
                width: 450.0,
                child: Text(
                  'Facility Address',
                  style: TextStyle(fontSize: 25),
                  textAlign: TextAlign.center,
                ),
              ),
              Container(
                padding: EdgeInsets.all(10),
                child: TextField(
                  enableInteractiveSelection: true,
                  maxLines: 5,
                  autocorrect: true,
                  autofocus: true,
                  enabled: true,
                  textAlign: TextAlign.center,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: "Address, City, State, Zip",
                  ),
                ),
              ),
              Container(
                padding: EdgeInsets.all(10),
                child: ButtonTheme(
                  minWidth: 300,
                  height: 45,
                  child: RaisedButton(
                    child: Text('Save/Send Note'),
                    textColor: Colors.white,
                    color: Colors.red[800],
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => NotePage()),
                      );
                    },

                  ),
                ),
              ),

            ],
          ),
        ),
      ),
    );
  }
}*/
